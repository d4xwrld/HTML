# Weekly Coding Challenge #1 -  Double slider Sign in/up Form - Desktop Only

A Pen created on CodePen.io. Original URL: [https://codepen.io/FlorinPop17/pen/vPKWjd](https://codepen.io/FlorinPop17/pen/vPKWjd).

My submission for week #1 of the Weekly Coding Challenge. Read more here: https://www.florin-pop.com/blog/2019/03/weekly-coding-challenge