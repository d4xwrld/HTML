# Pure CSS Foldable Birthday Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/lenasta92579651/pen/VwPMaOo](https://codepen.io/lenasta92579651/pen/VwPMaOo).

